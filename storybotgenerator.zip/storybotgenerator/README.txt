Grimoire Story Bot Generator
by ChaosRipjaw

For bot to work, must have the following three files in same directory as the exe:
-info.txt
-input.txt
-maps.txt

Can generate these three files with questparser.exe
See example folder for some examples

#info.txt
#0) gbot file name output
#1) author name
#2) colors for titles and stuff
#3) Title of bot in Grim
#4) Drops (put "<quest id>~" before drop name so quest can pick it up at the end, only when get drop is on)
#5) (optional) "get drop on" (if not, defaults to whitelist)

#input.txt
#<quest id> - <quest name>

#maps.txt
#				Initial join						specific per item								 auxiliary quests
#												i			i+1		i+2		 i+3	i+4	   i+5
#<1=farming,!1=solo>,<map name>,<cell>,<pad>,<temp item>;<quantity>;<packet>;<map>;<cell>;<pad>...,<quest ID>;<questID>;...
#											,<temp item>;<quantity>;<monster>;<map>;<cell>;<pad>...,<quest ID>;<questID>;...
#											,<item>;<quantity>;"shop"~<shop id>;<map>;<cell>;<pad>...,
#WARNING: DO NOT LEAVE TRAILING SEMICOLONS