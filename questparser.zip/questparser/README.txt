Quest Parser
by ChaosRipjaw

Generates the "info.txt", "input.txt", and "maps.txt" to use for story bot generator or Arts quest bot generator. 

1) Save loaded quests in Grimoire into a file called "ql.xml"
2) Put it in the same folder as questparser.exe 
3) Run.
4) Replace placeholder names with the correct ones

See example folder.