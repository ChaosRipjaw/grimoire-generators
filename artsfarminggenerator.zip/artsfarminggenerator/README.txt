Arts Farming Bot Generator
by ChaosRipjaw

This generator creates bots within bots in order to farm shops, quests, or quests to merge, etc.
Same as story bot generator, must have:
-info.txt
-input.txt
-maps.txt

Input is very confusing so don't be worried if you screw up, even I don't remember how it works.
See example folder.

# v4 Updates
# ALL drops must have specifiers:
#				i			i+1			  i+2			i+3
# drops = [<specifier>,<quest/shop id>,<drop name>,<drop quantity>, ...]
#		"quest"~<quest id>~<drop name>~<drop quantity>
#			quest reward you are farming for
#			-related to itemIds
#			-checked at ITEM/BOT MANAGER
#			-checked at UNBANK
#			-checked at MAIN CHECK
#			-checked at COMPLETE
#		"req"~<quest id>~<item name>~<item quantity>
#			must have before quest or shop can be done
#			-checked at UNBANK
#			-checked at MAIN CHECK
#		"shop"~<shop id>~<item name>~<item quantity>
#			shop item you are farming for
#			-related to itemIds
#			-checked at ITEM/BOT MANAGER
#			-checked at UNBANK
#			-checked at MAIN CHECK
#			-checked at COMPLETE
#		"reagent"~<quest/shop id>~<item name>~<item quantity>
#			farmable item you farm to spend
#			-related to mapPackets
#			-checked at UNBANK
#			-checked at MAIN CHECK
#		"none"~<don't care>~<item name>~<item quantity>
# 			picks up no matter what
#			-checked at UNBANK


# Fields obtained from txt files
#info.txt
# 	fileName=""
#	author=""
#	colors=[]
#	title=""
#	classes=[]
#	rotationNum=[]
#	drops=[]
#		"quest"~<quest id>~<drop name>~<drop quantity>
#		"req"~<quest id>~<item name>~<item quantity>
#		"shop"~<shop id>~<item name>~<item quantity>
#		"reagent"~<quest/shop id>~<item name>~<item quantity>
#	getDropOption=False
#input.txt
#	questIds=[]
#		none implies normal quest
#		"ql"~<questId>,		puts quest in quest list
#		"shop"~<shopId>,	for merge shops
#	questNames=[]
#		 - <quest name>
#		 - <shop name>
#maps.txt
#	questType=[]
#		"1001010..." per item
#	mapNames=[]
#	mapCells=[]
#	mapPads=[]
#	mapPackets=[]
#		< <item>;<quantity>;<source>;<map>;<cell>;<pad> >
#							packet
#							monster
#							"shop"~shop
#				v3			<source> (nested bot)
#	auxQuests=[]
#		<auxId>~"YES", checks if it can be completed at complete
#		<auxId>~"NO"
#	itemIds=[]
#		<itemName>~<itemId>

#v1
# Does one quest nonstop [COMPLETE]

#v2
# Should be able to do multiple quests with different objectives (Item Manager: rep, item in inventory)
#		- temp item
#		- primary items
#		- rep	[NOT IMPLEMENTED YET]
# If auxiliary quests are listed in input after main quest, those should be accepted too
# Should be able to 
#		- Farm a quest until all random drops are acquired
#		- Farm a quest until all chosen drops are acquired
#		- Farm monsters for merge resources only, like the merge is a quest

#v3
# Should be able to do quests inside quests (i.e. Legion Revenant, Willpower Extraction)
# The "main" bot loads the auxiliary quest bot
#		- Farm a quest until all merge shop items are bought
# Primary quest
# 	<questType>,<map>,<cell>,<pad>,<itemName>;<itemQuantity>;<source>;<map>;<cell>;<pad>
# secondary and below <source> = 
#   < <fileName>,<colorR>,<colorG>,<colorB>,<title>,<questIds>`<questIds>`...,<questNames>`<questNames>`... ,<questType>,<map>,<cell>,<pad>,<itemName>;<itemQuantity>;<source>;<map>;<cell>;<pad>...>